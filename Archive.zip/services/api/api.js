const authApi = 'https://staging.api.app.fleettracker.de/api/token'

const shipsApi = 'https://staging.api.app.fleettracker.de/api/ships'