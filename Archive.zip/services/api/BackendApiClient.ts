const API_BASE_URL = {
    development: 'https://api.dev.youpendo.com/api/v1',
    internal: 'https://api.staging.youpendo.com/api/v1',
    production: 'https://api.youpendo.com/api/v1',
  };